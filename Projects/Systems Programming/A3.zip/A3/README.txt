README
Austin Brooks 819274879 cssc1975 Project 3

Grammar
statement ::= <letter(s)> <number(s)> <' = '> <letter(s)> <number(s)><;>
letters ::= [a-z] | [A-Z]
numbers ::= [0-9]

listing
ex, exp.l, exp.y, makefile, README

Instructions: Follow exactly the makefile, this will produce an .exe, then 
use that on an example file(ex)

Issues: It was hard to look over blank lines and continuing to look past errors

Lessons learned: Flex and Bison makes this alot simpler than only c++

Additional information: N/A