'''
problemsearch - Functions for seaarching.
'''

from basicsearch_lib02.searchrep import (Node, print_nodes)
from basicsearch_lib02.queues import PriorityQueue
from explored import Explored


def graph_search(problem, verbose=False, debug=False):
    """graph_search(problem, verbose, debug) - Given a problem representation
    (instance of basicsearch_lib02.representation.Problem or derived class),
    attempt to solve the problem.

    If debug is True, debugging information will be displayed.

    if verbose is True, the following information will be displayed:

        Number of moves to solution
        List of moves and resulting puzzle states
        Example:

            Solution in 25 moves
            Initial state
                  0        1        2
            0     4        8        7
            1     5        .        2
            2     3        6        1
            Move 1 -  [0, -1]
                  0        1        2
            0     4        8        7
            1     .        5        2
            2     3        6        1
            Move 2 -  [1, 0]
                  0        1        2
            0     4        8        7
            1     3        5        2
            2     .        6        1

            ... more moves ...

                  0        1        2
            0     1        3        5
            1     4        2        .
            2     6        7        8
            Move 22 -  [-1, 0]
                  0        1        2
            0     1        3        .
            1     4        2        5
            2     6        7        8
            Move 23 -  [0, -1]
                  0        1        2
            0     1        .        3
            1     4        2        5
            2     6        7        8
            Move 24 -  [1, 0]
                  0        1        2
            0     1        2        3
            1     4        .        5
            2     6        7        8

        If no solution were found (not possible with the puzzles we
        are using), we would display:

            No solution found

    Returns a tuple (path, nodes_explored) where:
    path - list of actions to solve the problem or None if no solution was found
    nodes_explored - Number of nodes explored (dequeued from frontier)
    """

    #I get an extra class period to turn in assignments. Program was due last wednesday making it due 2/2 for me. Approved by Professor
    initial_node = Node(problem, problem.initial)
    frontier = PriorityQueue(f=lambda x: x.get_g())
    frontier.append(initial_node)

    move = -1
    done = False
    explored = Explored()
    path = list()
    while not done:
        node = frontier.pop()
        if debug:
            move += 1
            if move > 0:
                print(f'Move {move} - {node.action}')
                print(node.state.__repr__())
        explored.add(node.state)
        if problem.goal_test(node.state):
            done = True
            path = node.path()
        else:
            # only add novel results from current node
            nodes = node.expand(node.problem)
            for element in nodes:
                if explored.exists(element.state):
                    continue
                else:
                    frontier.append(element)
            done = frontier.__len__() < 0
    if verbose:
        print(f'Solution in {len(path)} moves')
        move = 0
        for temp_node in path:
            if move > 0:
                print(f'Move {move} - {temp_node.action}')
                print(temp_node.state.__repr__())
            else:
                print('Initial state')
                print(temp_node.state.__repr__())
            move += 1
    path = [x.action for x in path]
    return path, len(path), move, len(list(explored.explored_set))
