"""
searchstrategies

Module to provide implementations of g and h for various search strategies.
In each case, the functions are class methods as we don't need an instance
of the class.

If you are unfamiliar with Python class methods, Python uses a function
decorator (indicated by an @ to indicate that the next method is a class
method).  Example:

class SomeClass:
    @classmethod
    def foobar(cls, arg1, arg2):
        "foobar(arg1, arg2) - does ..."

        code... class variables are accessed as cls.var (if needed)
        return computed value

A caller would import SomeClass and then call, e.g. :
    SomeClass.foobar("hola","amigos")

Contains g and h functions for:
BreadFirst - breadth first search
DepthFirst - depth first search
Manhattan - city block heuristic search.  To restrict the complexity of
    this, you only need handle heuristics for puzzles with a single solution
    where the blank is at the bottom right, e.g.:
        123
        456
        78
    When multiple solutions are allowed, the heuristic becomes a little more
    complex as the city block distance must be estimated to each possible solution
    state.
"""

import math


# For each of the following classes, create classmethods g and h
# with the following signatures
#       @classmethod
#       def g(cls, parentnode, action, childnode):
#               return appropritate g value
#       @classmethod
#        def h(cls, state):
#               return appropriate h value

#I get an extra class period to turn in assignments. Program was due last wednesday making it due 2/2 for me. Approved by Professor

class BreadthFirst:
    "BredthFirst - breadthfirst search"
    @classmethod
    def g(cls, parentnode, action, childnode):
        return parentnode.depth + 1

    @classmethod
    def h(cls, state):
        return 0


class DepthFirst:
    "DepthFirst - depth first search"
    @classmethod
    def g(cls, parentnode,action, childnode):
        return parentnode.depth + 1

    @classmethod
    def h(cls, state):
        return 0


class Manhattan:
    "Manhattan Block Distance heuristic"

    @classmethod
    def g(cls, parentnode, action, childnode):
        return parentnode.depth + 1

    @classmethod
    def h(cls, state):
        manhattan_sum = 0
        rows = state.get_rows()
        cols = state.get_cols()
        for row in range(rows):
            for col in range(cols):
                # print(state.get(row, col), end="--")
                current_value = state.get(row, col)
                if current_value is None:
                    correct_row = rows - 1
                    correct_col = cols - 1
                else:
                    correct_row = (current_value - 1) // cols
                    correct_col = (current_value - 1) % cols
                m = abs(row - correct_row) + abs(col - correct_col)
                manhattan_sum += m
        return manhattan_sum



